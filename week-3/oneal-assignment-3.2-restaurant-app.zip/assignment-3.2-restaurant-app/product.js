/**
==============================================
; Title: Assignment 3.2 Restaurant App
; Author: Professor Krasso
; Modified By: Chad ONeal
; Date: 08/24/2022
; Description: product.js
==============================================
*/

//product class to be exported
export class Product {

    constructor(home, price) {

        this.name = home;
        this.price = price;
    }
}